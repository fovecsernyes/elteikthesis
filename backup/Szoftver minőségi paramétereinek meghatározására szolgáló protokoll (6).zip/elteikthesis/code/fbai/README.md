# Flappy Bird AI client
Bachelor thesis of Mark Vecsernyes

## Requirements:
see in document

Folders:
* documents: contain documents
* test: contains test files
* src contains source code
