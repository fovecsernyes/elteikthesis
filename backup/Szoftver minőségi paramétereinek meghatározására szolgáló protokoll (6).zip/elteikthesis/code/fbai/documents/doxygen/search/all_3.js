var searchData=
[
  ['database',['Database',['../classdatabase_1_1_database.html',1,'database.Database'],['../gameservices_8py.html#af60926eaad2fd2964c5ce03ff2ab92c7',1,'gameservices.database()']]],
  ['database_2epy',['database.py',['../database_8py.html',1,'']]],
  ['debug',['debug',['../app_8py.html#ab4a362027d4aa3246e0e0f57ebf177b0',1,'app']]]
];
