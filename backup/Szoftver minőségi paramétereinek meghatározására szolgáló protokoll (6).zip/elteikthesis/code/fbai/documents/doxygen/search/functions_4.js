var searchData=
[
  ['generate_5fnet',['generate_net',['../net_8py.html#a8f3e348f76fbbe58ca1f7513f7f93261',1,'net']]],
  ['genetic_5falgorithm',['genetic_algorithm',['../genetic_8py.html#a4e18c5e496fa5ab39ce490038971d2a6',1,'genetic']]]
];
