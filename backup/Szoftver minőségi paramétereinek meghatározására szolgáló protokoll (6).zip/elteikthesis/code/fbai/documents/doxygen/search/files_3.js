var searchData=
[
  ['gameservices_2epy',['gameservices.py',['../gameservices_8py.html',1,'']]],
  ['genetic_2epy',['genetic.py',['../genetic_8py.html',1,'']]]
];
