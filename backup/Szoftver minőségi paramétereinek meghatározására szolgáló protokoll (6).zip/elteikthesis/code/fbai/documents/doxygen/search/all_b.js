var searchData=
[
  ['select_5fbird',['select_bird',['../classdatabase_1_1_database.html#a07ae0a40b97e3ce515e4b8932225dad4',1,'database::Database']]],
  ['select_5ffitness',['select_fitness',['../classdatabase_1_1_database.html#a7bec1417d47fadcf0beb7d13362cad5d',1,'database::Database']]],
  ['selection_5fmethod',['selection_method',['../genetic_8py.html#a7e54df9a953dcea3e99bf55d7b23932a',1,'genetic']]],
  ['start_5fgen_5frequest',['start_gen_request',['../gameservices_8py.html#a1e1eac69dc6ac45820c31221566ae464',1,'gameservices']]],
  ['start_5frequest',['start_request',['../gameservices_8py.html#af2e88a22ee8129427c43bf9d4e846ef4',1,'gameservices']]]
];
