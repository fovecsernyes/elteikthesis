var searchData=
[
  ['make_5fmatrix',['make_matrix',['../genetic_8py.html#a113bac45cb23d1dc7368a27da0b5d32a',1,'genetic']]],
  ['make_5fodict',['make_odict',['../genetic_8py.html#a7a5d5179f221dc5714678f242183ed2c',1,'genetic']]],
  ['methods',['methods',['../app_8py.html#acc2d9f753751d59302fae3b2bfe99571',1,'app']]],
  ['mutation_5fmethod',['mutation_method',['../genetic_8py.html#a4bb3666e3dda3a553dd587784ae7fed6',1,'genetic']]]
];
