var searchData=
[
  ['methods',['methods',['../app_8py.html#acc2d9f753751d59302fae3b2bfe99571',1,'app']]]
];
