var searchData=
[
  ['insert_5fbird',['insert_bird',['../classdatabase_1_1_database.html#aebdb0b73ea3162aff98e580179ecb9a6',1,'database::Database']]],
  ['insert_5fcycle',['insert_cycle',['../classdatabase_1_1_database.html#a45a93335dce98de4143e03a88d2e960a',1,'database::Database']]],
  ['insert_5ffitness',['insert_fitness',['../classdatabase_1_1_database.html#ac2f1e4e78ab8b2f1e16ed413f853ca0c',1,'database::Database']]]
];
