var searchData=
[
  ['update_5fnet',['update_net',['../classdatabase_1_1_database.html#a5bcccfaf202c828a331357f47854746f',1,'database::Database']]]
];
